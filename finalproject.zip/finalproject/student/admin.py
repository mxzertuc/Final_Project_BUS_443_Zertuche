from django.contrib import admin
from student.models import Coursedetails, Studentdetails

# Register your models here.


admin.site.register(Coursedetails)

admin.site.register(Studentdetails)
