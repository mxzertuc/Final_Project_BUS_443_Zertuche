from django.db import models

# Create your models here.

class Coursedetails(models.Model):
	courseID = models.IntegerField()
	coursetitle = models.CharField(max_length=500)
	coursename = models.CharField(max_length=500)
	coursesectioncode = models.IntegerField()
	coursedepartment = models.CharField(max_length=500)
	instructorfullname = models.CharField(max_length=500)

class Studentdetails(models.Model):
	studentID = models.IntegerField()
	firstname = models.CharField(max_length=500)
	lastname = models.CharField(max_length=500)
	studentmajor = models.CharField(max_length=500)
	classyear = models.CharField(max_length=500)
	gpa = models.DecimalField(max_digits=3, decimal_places=2)

	
class Studentenrollment(models.Model):
	studentID = models.IntegerField()
	coursetitle = models.CharField(max_length=500)
	