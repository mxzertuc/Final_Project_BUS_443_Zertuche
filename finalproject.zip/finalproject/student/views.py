from django.shortcuts import render
from django.http import HttpResponse
from student.models import Coursedetails
from student.models import Studentdetails, Studentenrollment
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required


# Create your views here.

@login_required
def home(request):
	context = {'name':'Matias Zertuche'}
	return render(request, 'student/home.html', context)

@login_required
def coursedetails(request):
	coursedata = Coursedetails.objects.all()
	paginator = Paginator(coursedata, 10)
	page = request.GET.get('page')
	minidata = paginator.get_page(page)
	context = {'data':minidata}
	return render(request,'student/coursedetails.html', context)

@login_required
def studentdetails(request):
	studentdata = Studentdetails.objects.all()
	paginator = Paginator(studentdata, 10)
	page = request.GET.get('page')
	minidata = paginator.get_page(page)
	context = {'sdata':minidata}
	return render(request, 'student/studentdetails.html', context)

@login_required
def studentenrollment(request):
	coursedata = Coursedetails.objects.all()
	studentdata = Studentdetails.objects.all()
	if 'studentid' in request.session:
		enrollmentdata = Studentenrollment.objects.filter(studentID = request.session['studentid'])
	else:
		enrollmentdata = Studentenrollment.objects.all()
	context = {'student':studentdata, 'course':coursedata, 'enrollment':enrollmentdata }
	return render(request, 'student/enrollment.html', context)

def saveenroll(request):
	if('stuid' in request.GET and 'cenroll' not in request.GET):
		request.session['studentid'] = request.GET.get('stuid')
	if('stuid' and 'cenroll' in request.GET):
		studentid = request.GET.get('stuid')
		enrolledclass = request.GET.get('cenroll')
		dataobj = Studentenrollment(studentID=studentid, coursetitle=enrolledclass)
		dataobj.save()
	return HttpResponse("Success")